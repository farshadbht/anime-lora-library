from pathlib import Path
import os
import socket
import sys
import threading

import webview

# Project locations
if getattr(sys, "frozen", False):
    PROJECT_ROOT = Path(sys.executable).resolve().parent
else:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent

os.environ.setdefault("ANIME_LORA_HOME", str(PROJECT_ROOT))
SRC = PROJECT_ROOT / "src"

sys.path.insert(0, str(SRC))

import library_server


HOST = "127.0.0.1"
PORT = 8765
LIBRARY_URL = f"http://{HOST}:{PORT}/downloads/index.html"


def server_already_running():
    try:
        with socket.create_connection((HOST, PORT), timeout=0.5):
            return True
    except OSError:
        return False


def main():
    print("Preparing Anime LoRA Library...")

    os.chdir(PROJECT_ROOT)

    # Create missing data folders and default files safely.
    library_server.initialize_data()

    # Refresh both offline HTML pages.
    library_server.generate()

    server = None

    if server_already_running():
        print("Existing library server detected. Reusing it.")
    else:
        print("Starting library server...")

        from http.server import ThreadingHTTPServer

        server = ThreadingHTTPServer(
            (HOST, PORT),
            library_server.LibraryHandler
        )

        server_thread = threading.Thread(
            target=server.serve_forever,
            daemon=True
        )
        server_thread.start()

        print("Library server started.")

    try:
        print("Opening desktop application...")

        window = webview.create_window(
            title="Anime LoRA Library",
            url=LIBRARY_URL,
            width=1400,
            height=900,
            min_size=(960, 640),
            background_color="#17171d"
        )

        webview.start()

    finally:
        if server is not None:
            print("Stopping library server...")
            server.shutdown()
            server.server_close()

        print("Anime LoRA Library closed.")


if __name__ == "__main__":
    main()
